// BookAdapter.java
package com.example.mybookstore;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class BookAdapter extends RecyclerView.Adapter<BookAdapter.BookViewHolder> {

    private List<Book> bookList;

    public BookAdapter(List<Book> bookList) {
        this.bookList = bookList;
    }

    @NonNull
    @Override
    public BookViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_book, parent, false);
        return new BookViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull BookViewHolder holder, int position) {
        Book book = bookList.get(position);
        holder.author.setText(book.getAuthor());
        holder.bookid.setText(book.getBookid());
        holder.bookname.setText(book.getBookname());
        holder.category.setText(book.getCategory());
        holder.country.setText(book.getCountry());
        holder.price.setText(book.getPrice());
        holder.publisher.setText(book.getPublisher());
        holder.amount.setText(String.valueOf(book.getAmount()));
    }

    @Override
    public int getItemCount() {
        return bookList.size();
    }

    public static class BookViewHolder extends RecyclerView.ViewHolder {
        TextView author, bookid, bookname, category, country, price, publisher, amount;

        public BookViewHolder(@NonNull View itemView) {
            super(itemView);
            author = itemView.findViewById(R.id.author);
            bookid = itemView.findViewById(R.id.bookid);
            bookname = itemView.findViewById(R.id.bookname);
            category = itemView.findViewById(R.id.category);
            country = itemView.findViewById(R.id.country);
            price = itemView.findViewById(R.id.price);
            publisher = itemView.findViewById(R.id.publisher);
            amount = itemView.findViewById(R.id.amount);
        }
    }
}