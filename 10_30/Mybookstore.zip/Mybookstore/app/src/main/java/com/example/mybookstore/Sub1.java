package com.example.mybookstore;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class Sub1 extends AppCompatActivity {

    Button home1;
    Button mn_bt1;
    Button mn_bt2;
    Button mn_bt3;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_sub1);

        home1 = findViewById(R.id.home1);

        home1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Sub1.this , MainActivity.class);
                startActivity(intent);
            }
        });

        mn_bt1 = findViewById(R.id.mn_bt1);

        mn_bt1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Sub1.this , sub2.class);
                startActivity(intent);
            }
        });

        mn_bt2 = findViewById(R.id.mn_bt2);

        mn_bt2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Sub1.this , sub3.class);
                startActivity(intent);
            }
        });

        mn_bt3 = findViewById(R.id.mn_bt3);

        mn_bt3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Sub1.this , sub4.class);
                startActivity(intent);
            }
        });

    }
}