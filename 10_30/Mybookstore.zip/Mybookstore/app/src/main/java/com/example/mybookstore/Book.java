package com.example.mybookstore;
// Book.java
public class Book {
    private String author;
    private String bookid;
    private String bookname;
    private String category;
    private String country;
    private String price;
    private String publisher;
    private int amount;

    // 빈 생성자가 필요합니다(Firestore에서 필요)
    public Book() {}

    public Book(String author, String bookid, String bookname, String category, String country, String price, String publisher, int amount) {
        this.author = author;
        this.bookid = bookid;
        this.bookname = bookname;
        this.category = category;
        this.country = country;
        this.price = price;
        this.publisher = publisher;
        this.amount = amount;
    }

    public String getAuthor() { return author; }
    public String getBookid() { return bookid; }
    public String getBookname() { return bookname; }
    public String getCategory() { return category; }
    public String getCountry() { return country; }
    public String getPrice() { return price; }
    public String getPublisher() { return publisher; }
    public int getAmount() { return amount; }
}
