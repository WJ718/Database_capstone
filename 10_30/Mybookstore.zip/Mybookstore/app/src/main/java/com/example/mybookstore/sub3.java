package com.example.mybookstore;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
// sub3.java
public class sub3 extends AppCompatActivity {

    Button home3;
    Button mc_b1;
    Button mc_b2;
    Button mc_b3;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_sub3);

        home3 = findViewById(R.id.home3);

        home3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(sub3.this , MainActivity.class);
                startActivity(intent);
            }
        });

        mc_b1 = findViewById(R.id.mc_b1);

        mc_b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(sub3.this , Sub1.class);
                startActivity(intent);
            }
        });
        mc_b2 = findViewById(R.id.mc_b2);

        mc_b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(sub3.this , sub2.class);
                startActivity(intent);
            }
        });

        mc_b3 = findViewById(R.id.mc_b3);

        mc_b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(sub3.this , sub4.class);
                startActivity(intent);
            }
        });

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
}