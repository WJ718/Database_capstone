package com.example.mybookstore;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import java.util.ArrayList;
import java.util.List;

public class sub2 extends AppCompatActivity {

    private RecyclerView recyclerView;
    private BookAdapter bookAdapter;
    private List<Book> bookList;
    private FirebaseFirestore db = FirebaseFirestore.getInstance();

    Button home2;
    Button ma_bt1;
    Button ma_bt2;
    Button ma_bt3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_sub2);

        // 초기화
        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        bookList = new ArrayList<>();
        bookAdapter = new BookAdapter(bookList);
        recyclerView.setAdapter(bookAdapter);

        // Firestore에서 데이터 로드
        loadBooksFromFirestore();

        // 버튼 설정
        home2 = findViewById(R.id.home2);
        home2.setOnClickListener(view -> {
            Intent intent = new Intent(sub2.this, MainActivity.class);
            startActivity(intent);
        });

        ma_bt1 = findViewById(R.id.ma_bt1);
        ma_bt1.setOnClickListener(view -> {
            Intent intent = new Intent(sub2.this, Sub1.class);
            startActivity(intent);
        });

        ma_bt2 = findViewById(R.id.ma_bt2);
        ma_bt2.setOnClickListener(view -> {
            Intent intent = new Intent(sub2.this, sub3.class);
            startActivity(intent);
        });

        ma_bt3 = findViewById(R.id.ma_bt3);
        ma_bt3.setOnClickListener(view -> {
            Intent intent = new Intent(sub2.this, sub4.class);
            startActivity(intent);
        });

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    private void loadBooksFromFirestore() {
        CollectionReference booksRef = db.collection("books");
        booksRef.get().addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                bookList.clear();
                for (QueryDocumentSnapshot document : task.getResult()) {
                    Book book = document.toObject(Book.class);
                    bookList.add(book);
                }
                bookAdapter.notifyDataSetChanged();
            } else {
                Log.d("sub2", "Error getting documents: ", task.getException());
            }
        });
    }
}
