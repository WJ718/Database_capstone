package com.example.mytravel
// AppAdapter.kt
import android.app.AlertDialog
import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.mytravel.databinding.AppItemLayoutBinding
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

// AppAdapter 클래스는 RecyclerView.Adapter를 상속받아 RecyclerView 어댑터 역할을 한다.
class AppAdapter(
    // 생성자들
    private val appList: MutableList<AppItem>,                  // 표시할 앱 목록을 담는 리스트
    private val context: Context,                               // 다이얼로그 표시에 사용할 컨텍스트
    private val recyclerView: RecyclerView,                     // 해당 어댑터와 연결된 RecyclerView - FirstFragment에서사용
    private val onItemClick: (AppItem) -> Unit                  // 앱 아이템이 클릭될 때 실행되는 람다함수로, AppItem 객체를 전달함
) : RecyclerView.Adapter<AppAdapter.AppViewHolder>() {

    // 내부 클래스로 , 각 아이템 뷰를 관리, 뷰 바인딩을 통해 레이아웃의 뷰 요소에 접근함.
    inner class AppViewHolder(val binding: AppItemLayoutBinding) : RecyclerView.ViewHolder(binding.root)

    // RecyclerView가 각 아이템 뷰를 생성할 때 호출함. - 
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): AppViewHolder {
        // AppItemLayoutBinding을 사용해 xml 레이아웃을 뷰 객체로 전환
        val binding = AppItemLayoutBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return AppViewHolder(binding)
    }

    // viewholder가 화면에 표시될 때 호출.
    override fun onBindViewHolder(holder: AppViewHolder, position: Int) {
        // appItem을 받아와 
        val appItem = appList[position]
        // 해당 앱의 아이콘을 appIcon 뷰에 설정함
        holder.binding.appIcon.setImageDrawable(appItem.appIcon)

        // 클릭 리스너 추가: 아이템 클릭 시 onItemClick 호출
        holder.itemView.setOnClickListener {
            onItemClick(appItem) // 클릭된 앱 정보를 콜백으로 전달
        }

        // 롱클릭 리스너 추가: 아이템 길게 눌렀을 때 삭제 다이얼로그 표시
        holder.itemView.setOnLongClickListener {
            CoroutineScope(Dispatchers.Main).launch {
                showDeleteDialog(position)
            }
            true
        }
    }

    private suspend fun showDeleteDialog(position: Int) = withContext(Dispatchers.Main) {
        val builder = AlertDialog.Builder(context)
        builder.setTitle("앱 삭제")
        builder.setMessage("이 앱을 삭제하시겠습니까?")
        builder.setPositiveButton("삭제") { dialog, _ ->
            CoroutineScope(Dispatchers.IO).launch {
                if (position >= 0 && position < appList.size) { // 유효한 인덱스인지 확인
                    // 삭제된 앱의 이름을 removedApp에 저장
                    val removedApp = appList.removeAt(position)
                    withContext(Dispatchers.Main) {
                        notifyItemRemoved(position)
                    }

                    // SharedPreferences 업데이트
                    val sharedPreferences = context.getSharedPreferences("myPrefs", Context.MODE_PRIVATE)
                    val editor = sharedPreferences.edit()
                    val appListString = appList.joinToString(",") { it.packageName }
                    editor.putString("appListKey", appListString)
                    editor.apply()
                }
                dialog.dismiss()
            }
        }
        builder.setNegativeButton("취소") { dialog, _ -> dialog.dismiss() }
        builder.show()
    }


    override fun getItemCount() = appList.size

    // 아이템 위치 교체 (드래그 이벤트에서 호출)
    fun swapItems(fromPosition: Int, toPosition: Int) {
        val temp = appList[fromPosition]
        appList[fromPosition] = appList[toPosition]
        appList[toPosition] = temp
        notifyItemMoved(fromPosition, toPosition)

        // 배치를 바꾼 후에 플로팅 위젯을 업데이트
        val sharedPreferences = context.getSharedPreferences("myPrefs", Context.MODE_PRIVATE)
        val editor = sharedPreferences.edit()
        val appListString = appList.joinToString(",") { it.packageName } // 각 appItem의 패키지명을 사용해 문자열로 변환
        editor.putString("appListKey", appListString)
        editor.apply()
    }
}
