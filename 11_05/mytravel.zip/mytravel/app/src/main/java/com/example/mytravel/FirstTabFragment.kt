package com.example.mytravel
//FirstTabFragment.kt
import android.content.Context
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.drawable.Drawable
import android.os.Bundle
import android.view.*
import android.widget.ArrayAdapter
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.RecyclerView
import com.example.mytravel.databinding.FragmentFirstTabBinding
import com.example.mytravel.databinding.AppItemLayoutBinding

data class AppItem(val appName: String, val appIcon: Drawable, val packageName: String)

class FirstTabFragment : Fragment() {

    private var _binding: FragmentFirstTabBinding? = null
    private val binding get() = _binding!!

    private lateinit var appAdapter: AppAdapter
    private val appList: MutableList<AppItem> = mutableListOf()
    private var deleteDialog: AlertDialog? = null

    private val preferenceChangeListener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
        if (key == "appListKey") {
            appList.clear()
            initializeAppListFromSharedPreferences()
            appAdapter.notifyDataSetChanged()
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        _binding = FragmentFirstTabBinding.inflate(inflater, container, false)
        val view = binding.root

        val sharedPreferences = requireContext().getSharedPreferences("myPrefs", Context.MODE_PRIVATE)
        sharedPreferences.registerOnSharedPreferenceChangeListener(preferenceChangeListener)

        initializeAppListFromSharedPreferences()

        binding.appContainer.apply {
            appAdapter = AppAdapter(appList, requireContext(), this) { app ->
                launchApp(app.packageName)
            }
            adapter = appAdapter
            layoutManager = GridLayoutManager(context, 4)
        }

        val itemTouchHelperCallback = object : ItemTouchHelper.Callback() {
            override fun getMovementFlags(recyclerView: RecyclerView, viewHolder: RecyclerView.ViewHolder): Int {
                val dragFlags = ItemTouchHelper.UP or ItemTouchHelper.DOWN or
                        ItemTouchHelper.LEFT or ItemTouchHelper.RIGHT
                return makeMovementFlags(dragFlags, 0)
            }

            override fun onMove(recyclerView: RecyclerView, viewHolder: RecyclerView.ViewHolder, target: RecyclerView.ViewHolder): Boolean {
                appAdapter.swapItems(viewHolder.adapterPosition, target.adapterPosition)
                return true
            }

            override fun onSwiped(viewHolder: RecyclerView.ViewHolder, direction: Int) {}

            override fun onSelectedChanged(viewHolder: RecyclerView.ViewHolder?, actionState: Int) {
                super.onSelectedChanged(viewHolder, actionState)
                if (actionState == ItemTouchHelper.ACTION_STATE_DRAG) {
                    deleteDialog?.let {
                        if (it.isShowing) {
                            it.dismiss()
                            deleteDialog = null
                        }
                    }
                }
            }
        }

        val itemTouchHelper = ItemTouchHelper(itemTouchHelperCallback)
        itemTouchHelper.attachToRecyclerView(binding.appContainer)

        binding.icAddbox.setOnClickListener {
            showAppSelectionDialog()
        }

        binding.reset.setOnClickListener {
            appList.clear()
            appAdapter.notifyDataSetChanged()

            val editor = sharedPreferences.edit()
            editor.putString("appListKey", "")
            editor.apply()
        }

        return view
    }

    private fun initializeAppListFromSharedPreferences() {
        appList.clear()

        val sharedPreferences = requireContext().getSharedPreferences("myPrefs", Context.MODE_PRIVATE)
        val appListString = sharedPreferences.getString("appListKey", "")

        if (appListString.isNullOrEmpty()) return

        val installedApps = requireContext().packageManager.getInstalledApplications(PackageManager.GET_META_DATA)
        appListString.split(",").filter { it.isNotEmpty() }.forEach { packageName ->
            installedApps.find { it.packageName == packageName &&
                    requireContext().packageManager.getLaunchIntentForPackage(it.packageName) != null
            }?.let { appInfo ->
                val appName = appInfo.loadLabel(requireContext().packageManager).toString()
                val appIcon = appInfo.loadIcon(requireContext().packageManager)
                appList.add(AppItem(appName, appIcon, packageName))
            }
        }
    }

    private fun launchApp(packageName: String) {
        val intent = requireContext().packageManager.getLaunchIntentForPackage(packageName)
        if (intent != null) {
            startActivity(intent)
        } else {
            Toast.makeText(requireContext(), "앱을 실행할 수 없습니다.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun showAppSelectionDialog() {
        val packageManager = requireContext().packageManager
        val installedApps = packageManager.getInstalledApplications(PackageManager.GET_META_DATA)

        val filteredApps = installedApps.filter { appInfo ->
            val launchIntent = packageManager.getLaunchIntentForPackage(appInfo.packageName)
            val isLaunchable = launchIntent != null
            val appName = appInfo.loadLabel(packageManager).toString()
            val isValidAppName = appName.isNotBlank() && !appName.contains("cutout", ignoreCase = true) &&
                    !appName.contains("uwb", ignoreCase = true) && !appName.contains("services library", ignoreCase = true)
            isLaunchable && isValidAppName
        }

        val appNamesArray = filteredApps.map { it.loadLabel(packageManager).toString() }.toTypedArray()
        val appIconsArray = filteredApps.map { it.loadIcon(packageManager) }.toTypedArray()
        val packageNamesArray = filteredApps.map { it.packageName }.toTypedArray()

        val builder = AlertDialog.Builder(requireContext())
        builder.setTitle("앱을 선택하세요")
        builder.setAdapter(
            ArrayAdapterWithIcon(requireContext(), appNamesArray, appIconsArray)
        ) { _, which ->
            val selectedAppName = appNamesArray[which]
            val selectedAppIcon = appIconsArray[which]
            val selectedPackageName = packageNamesArray[which]

            val sharedPreferences = requireContext().getSharedPreferences("myPrefs", Context.MODE_PRIVATE)
            val editor = sharedPreferences.edit()

            val currentAppList = sharedPreferences.getString("appListKey", "") ?: ""
            val updatedAppList = if (currentAppList.split(",").contains(selectedPackageName)) {
                currentAppList
            } else {
                if (currentAppList.isEmpty()) selectedPackageName else "$currentAppList,$selectedPackageName"
            }
            editor.putString("appListKey", updatedAppList)
            editor.apply()

            if (!appList.any { it.packageName == selectedPackageName }) {
                appList.add(AppItem(selectedAppName, selectedAppIcon, selectedPackageName))
                appAdapter.notifyItemInserted(appList.size - 1)
            }
        }

        builder.show()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null

        val sharedPreferences = requireContext().getSharedPreferences("myPrefs", Context.MODE_PRIVATE)
        sharedPreferences.unregisterOnSharedPreferenceChangeListener(preferenceChangeListener)
    }
}

class ArrayAdapterWithIcon(
    context: Context,
    private val appNames: Array<String>,
    private val appIcons: Array<Drawable>
) : ArrayAdapter<String>(context, android.R.layout.select_dialog_item, appNames) {

    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        val inflater = LayoutInflater.from(context)
        val view = inflater.inflate(android.R.layout.select_dialog_item, parent, false)

        val textView = view.findViewById<TextView>(android.R.id.text1)
        textView.text = appNames[position]
        textView.setCompoundDrawablesWithIntrinsicBounds(appIcons[position], null, null, null)
        textView.compoundDrawablePadding = 16
        return view
    }
}
