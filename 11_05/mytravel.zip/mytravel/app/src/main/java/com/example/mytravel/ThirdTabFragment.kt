package com.example.mytravel

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment

class ThirdTabFragment : Fragment() {
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // fragment_third_tab.xml 레이아웃을 inflate합니다.
        return inflater.inflate(R.layout.fragment_third_tab, container, false)
    }
}
