package com.example.mytravel
// MainActivity.kt
import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.viewpager2.adapter.FragmentStateAdapter
import com.example.mytravel.databinding.ActivityMainBinding
import com.google.android.material.tabs.TabLayoutMediator
import androidx.activity.OnBackPressedCallback


// 권한 및 휴대폰 자체의 뒤로가기 기능 설정
class MainActivity : AppCompatActivity() {

    // screen on / off 브로드캐스트 리시버 설정
    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            when (intent?.action) {
                Intent.ACTION_SCREEN_ON -> Log.d("ScreenReceiver","screen ON")
                Intent.ACTION_SCREEN_OFF -> Log.d("ScreenReceiver","screen OFF")
            }
        }
    }

    // 뒤로 가기 버튼 클릭 시간 저장 변수
    private var backPressedTime: Long = 0

    // Toast 메시지 객체
    private lateinit var backToast: Toast

    private val LOCATION_PERMISSION_REQUEST_CODE = 1
    private val REQUEST_CODE_OVERLAY_PERMISSION = 100

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // 오버레이 권한 체크 및 요청
        checkOverlayPermission()
        // 위치 정보 권한 체크 및 요청
        checkLocationPermission()

        // 위치 권한 요청 및 처리
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (!Settings.canDrawOverlays(this)) {
                val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
                startActivityForResult(intent, REQUEST_CODE_OVERLAY_PERMISSION)
            } else {
                // 권한이 있으면 서비스 시작
                startForegroundServiceIfNeeded()
            }
        } else {
            startForegroundServiceIfNeeded()
        }

        // onBackPressedDispatcher 사용하여 뒤로가기 동작 정의
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (backPressedTime + 3000 > System.currentTimeMillis()) {
                    backToast.cancel()
                    finishAffinity()
                    System.exit(0)
                } else {
                    backToast = Toast.makeText(this@MainActivity, "앱을 종료하려면 뒤로가기를 한 번 더 누르세요", Toast.LENGTH_SHORT)
                    backToast.show()
                }
                backPressedTime = System.currentTimeMillis()
            }
        })


        // UI 설정 및 탭 초기화
        setupTabLayout(binding)
        setupViewPagerAndTabLayout(binding)
    }

    // 위치 권한이 있는지 확인하고, 없는 경우 요청
    private fun checkLocationPermission(): Boolean {
        return if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
            != PackageManager.PERMISSION_GRANTED) {
            // 권한이 없는 경우 권한 요청
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), LOCATION_PERMISSION_REQUEST_CODE)
            false
        } else {
            // 이미 권한이 있는 경우
            true
        }
    }

    // 오버레이 권한 확인 및 요청
    private fun checkOverlayPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (!Settings.canDrawOverlays(this)) {
                val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
                startActivityForResult(intent, REQUEST_CODE_OVERLAY_PERMISSION)
            }
        }
    }

    // Foreground 서비스 시작
    private fun startForegroundServiceIfNeeded() {
        val serviceIntent = Intent(this, MyForegroundService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(serviceIntent)
        } else {
            startService(serviceIntent)
        }
    }

    // TabLayout 설정
    private fun setupTabLayout(binding: ActivityMainBinding) {
        val tabLayout = binding.tabs
        tabLayout.addTab(tabLayout.newTab().setIcon(R.drawable.ic_add).setContentDescription("Add Item"))
        tabLayout.addTab(tabLayout.newTab().setIcon(R.drawable.ic_scheduler).setContentDescription("Scheduler"))
        tabLayout.addTab(tabLayout.newTab().setIcon(R.drawable.ic_settings).setContentDescription("Settings"))

        for (i in 0 until tabLayout.tabCount) {
            val tab = (tabLayout.getChildAt(0) as? android.widget.LinearLayout)?.getChildAt(i)
            tab?.setPadding(50, 0, 50, 0)
        }
    }

    // ViewPager2와 TabLayout 연결
    private fun setupViewPagerAndTabLayout(binding: ActivityMainBinding) {
        val viewPager = binding.viewPager
        viewPager.adapter = object : FragmentStateAdapter(this) {
            override fun getItemCount(): Int = 3
            override fun createFragment(position: Int): Fragment {
                return when (position) {
                    0 -> FirstTabFragment()
                    1 -> SecondTabFragment()
                    else -> ThirdTabFragment()
                }
            }
        }

        val tabLayout = binding.tabs
        TabLayoutMediator(tabLayout, viewPager) { tab, position ->
            when (position) {
                0 -> tab.setIcon(R.drawable.ic_add).setContentDescription("Add Item")
                1 -> tab.setIcon(R.drawable.ic_scheduler).setContentDescription("Scheduler")
                2 -> tab.setIcon(R.drawable.ic_settings).setContentDescription("Settings")
            }
        }.attach()
    }

    // 권한 요청 결과 처리
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == LOCATION_PERMISSION_REQUEST_CODE) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "위치 권한이 승인되었습니다.", Toast.LENGTH_SHORT).show()
                startForegroundServiceIfNeeded() // 위치 권한이 승인된 후 Foreground Service 시작
            } else {
                Toast.makeText(this, "위치 권한이 거부되었습니다. 설정에서 권한을 부여하세요.", Toast.LENGTH_LONG).show()
            }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_CODE_OVERLAY_PERMISSION) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                if (Settings.canDrawOverlays(this)) {
                    Toast.makeText(this, "오버레이 권한이 승인되었습니다.", Toast.LENGTH_SHORT).show()
                    startForegroundServiceIfNeeded()
                } else {
                    Toast.makeText(this, "오버레이 권한이 거부되었습니다. 설정에서 권한을 부여하세요.", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        // 서비스 중지
        stopService(Intent(this, MyForegroundService::class.java))
        System.exit(0)
    }
}
