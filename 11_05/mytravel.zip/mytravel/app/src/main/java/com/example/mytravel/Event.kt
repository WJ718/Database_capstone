// Event.kt
package com.example.mytravel

data class Event(
    val date: Long,
    val time: String,
    val title: String,
    val description: String
)