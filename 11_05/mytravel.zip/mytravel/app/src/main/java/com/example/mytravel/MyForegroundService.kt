// MyForegroundService.kt
package com.example.mytravel

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Toast
import androidx.core.app.NotificationCompat
import com.example.mytravel.databinding.FloatingWidgetBinding
import com.example.mytravel.databinding.AppItemLayoutBinding
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.abs
import kotlin.math.roundToInt

class MyForegroundService : Service() {

    private val CHANNEL_ID = "MyForegroundServiceChannel"
    private lateinit var windowManager: WindowManager
    private lateinit var binding: FloatingWidgetBinding
    private val serviceScope = CoroutineScope(Dispatchers.Main)
    private val appList: MutableList<AppItem> = mutableListOf()

    private var initialX = 0
    private var initialY = 0
    private var initialTouchX = 0f
    private var initialTouchY = 0f

    // 드래그 거리 임계값 설정
    private val clickThreshold = 10 // 단위: px

    private val preferenceChangeListener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
        if (key == "appListKey") {
            addAppListToFloatingWidget()
        }
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()

        val sharedPreferences = getSharedPreferences("myPrefs", Context.MODE_PRIVATE)
        sharedPreferences.registerOnSharedPreferenceChangeListener(preferenceChangeListener)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val notification: Notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Floating Widget Service")
            .setContentText("앱이 백그라운드에서 실행 중입니다.")
            .setSmallIcon(R.drawable.ic_notification)
            .build()

        startForeground(1, notification)

        if (Settings.canDrawOverlays(this)) {
            serviceScope.launch {
                createFloatingWidget()
            }
        } else {
            Toast.makeText(this, "오버레이 권한이 필요합니다.", Toast.LENGTH_LONG).show()
        }
        return START_NOT_STICKY
    }

    private suspend fun createFloatingWidget() {
        withContext(Dispatchers.Main) {
            windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
            val params = WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                else
                    WindowManager.LayoutParams.TYPE_PHONE,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT
            )

            params.gravity = Gravity.TOP or Gravity.END
            params.x = 0
            params.y = 100

            binding = FloatingWidgetBinding.inflate(LayoutInflater.from(this@MyForegroundService))

            // 드래그 기능 추가
            binding.floatingButton.setOnTouchListener { view, event ->
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        // 초기 위치와 터치 시작 위치 저장
                        initialX = params.x
                        initialY = params.y
                        initialTouchX = event.rawX
                        initialTouchY = event.rawY
                        true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        // 이동 거리 계산 후 위치 업데이트
                        params.x = initialX + (event.rawX - initialTouchX).roundToInt()
                        params.y = initialY + (event.rawY - initialTouchY).roundToInt()
                        windowManager.updateViewLayout(binding.root, params)
                        true
                    }
                    MotionEvent.ACTION_UP -> {
                        // 드래그 거리가 작으면 클릭으로 간주하여 클릭 이벤트 호출
                        val deltaX = abs(event.rawX - initialTouchX)
                        val deltaY = abs(event.rawY - initialTouchY)
                        if (deltaX < clickThreshold && deltaY < clickThreshold) {
                            view.performClick() // 클릭 이벤트 발생
                        }
                        true
                    }
                    else -> false
                }
            }

            // 클릭 리스너
            binding.floatingButton.setOnClickListener {
                if (binding.appListContainer.visibility == View.GONE) {
                    expandFloatingWidget()
                } else {
                    collapseFloatingWidget()
                }
            }

            windowManager.addView(binding.root, params)
            addAppListToFloatingWidget()
        }
    }

    private fun addAppListToFloatingWidget() {
        appList.clear()
        appList.addAll(loadAppListFromPreferences())

        binding.appListContainer.removeAllViews()

        val inflater = LayoutInflater.from(this)
        appList.forEach { appItem ->
            val itemBinding = AppItemLayoutBinding.inflate(inflater, binding.appListContainer, false)
            itemBinding.appIcon.setImageDrawable(appItem.appIcon)

            itemBinding.root.setOnClickListener {
                launchApp(appItem.packageName)
            }

            binding.appListContainer.addView(itemBinding.root)
        }
    }

    private fun loadAppListFromPreferences(): List<AppItem> {
        val sharedPreferences = getSharedPreferences("myPrefs", Context.MODE_PRIVATE)
        val appListString = sharedPreferences.getString("appListKey", "")
        val installedApps = packageManager.getInstalledApplications(PackageManager.GET_META_DATA)

        return appListString?.split(",")?.filter { it.isNotEmpty() }?.mapNotNull { packageName ->
            installedApps.find { it.packageName == packageName }?.let { appInfo ->
                val appName = appInfo.loadLabel(packageManager).toString()
                val appIcon = appInfo.loadIcon(packageManager)
                AppItem(appName, appIcon, packageName)
            }
        } ?: emptyList()
    }

    private fun expandFloatingWidget() {
        binding.appListContainer.visibility = View.VISIBLE
        binding.floatingButton.text = "앱 목록"
        addAppListToFloatingWidget()
    }

    private fun collapseFloatingWidget() {
        binding.appListContainer.visibility = View.GONE
        binding.floatingButton.text = "+"
    }

    private fun launchApp(packageName: String) {
        val intent = packageManager.getLaunchIntentForPackage(packageName)
        if (intent != null) {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(intent)
        } else {
            Toast.makeText(this, "앱을 실행할 수 없습니다.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val serviceChannel = NotificationChannel(
                CHANNEL_ID,
                "Foreground Service Channel",
                NotificationManager.IMPORTANCE_DEFAULT
            )
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(serviceChannel)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        val sharedPreferences = getSharedPreferences("myPrefs", Context.MODE_PRIVATE)
        sharedPreferences.unregisterOnSharedPreferenceChangeListener(preferenceChangeListener)

        if (::binding.isInitialized) {
            windowManager.removeView(binding.root)
        }
        serviceScope.cancel()
        stopForeground(true)
        stopSelf()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
