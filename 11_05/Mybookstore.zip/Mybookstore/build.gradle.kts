// Top-level build file where you can add configuration options common to all sub-projects/modules.
// 프로젝트 단위의 build.gradle.kts
// 프로젝트의 build.gradle.kts (최상위)
plugins {
    alias(libs.plugins.android.application) apply false
    alias(libs.plugins.kotlin.android) apply false
}
