// 파일: OrderListActivity.kt
package com.example.mybookstore

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.mybookstore.databinding.ActivityOrderListBinding

class OrderListActivity : AppCompatActivity() {
    private lateinit var binding: ActivityOrderListBinding
    private lateinit var orderAdapter: OrderAdapter
    private lateinit var orderDao: OrderDao

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityOrderListBinding.inflate(layoutInflater)
        setContentView(binding.root)

        orderDao = OrderDao(this)
        orderAdapter = OrderAdapter(orderDao.getAllOrders().toMutableList(), orderDao)

        binding.recyclerViewOrders.apply {
            layoutManager = LinearLayoutManager(this@OrderListActivity)
            adapter = orderAdapter
        }

        binding.btnAddOrder.setOnClickListener {
            // 주문 추가 로직
        }
    }
}
