// 파일: CustomerDao.kt
package com.example.mybookstore

import android.content.ContentValues
import android.content.Context
import com.example.mybookstore.model.Customer

class CustomerDao(context: Context) {
    private val dbHelper = BookStoreDatabaseHelper(context)

    fun addCustomer(customer: Customer): Long {
        val db = dbHelper.writableDatabase
        val values = ContentValues().apply {
            put(BookStoreDatabaseHelper.COLUMN_CUST_ID, customer.custid)
            put(BookStoreDatabaseHelper.COLUMN_NAME, customer.name)
            put(BookStoreDatabaseHelper.COLUMN_BIRTH, customer.birth)
            put(BookStoreDatabaseHelper.COLUMN_GENDER, customer.gender)
            put(BookStoreDatabaseHelper.COLUMN_ADDRESS, customer.address)
            put(BookStoreDatabaseHelper.COLUMN_PHONE_NUM, customer.phonenum)
        }
        return db.insert(BookStoreDatabaseHelper.TABLE_CUSTOMERS, null, values)
    }

    fun getAllCustomers(): List<Customer> {
        val db = dbHelper.readableDatabase
        val cursor = db.query(
            BookStoreDatabaseHelper.TABLE_CUSTOMERS,
            null, null, null, null, null, null
        )
        val customers = mutableListOf<Customer>()
        with(cursor) {
            while (moveToNext()) {
                val customer = Customer(
                    custid = getInt(getColumnIndexOrThrow(BookStoreDatabaseHelper.COLUMN_CUST_ID)),
                    name = getString(getColumnIndexOrThrow(BookStoreDatabaseHelper.COLUMN_NAME)),
                    birth = getString(getColumnIndexOrThrow(BookStoreDatabaseHelper.COLUMN_BIRTH)),
                    gender = getString(getColumnIndexOrThrow(BookStoreDatabaseHelper.COLUMN_GENDER)),
                    address = getString(getColumnIndexOrThrow(BookStoreDatabaseHelper.COLUMN_ADDRESS)),
                    phonenum = getString(getColumnIndexOrThrow(BookStoreDatabaseHelper.COLUMN_PHONE_NUM))
                )
                customers.add(customer)
            }
        }
        cursor.close()
        return customers
    }

    fun deleteCustomer(customerId: Int): Int {
        val db = dbHelper.writableDatabase
        return db.delete(
            BookStoreDatabaseHelper.TABLE_CUSTOMERS,
            "${BookStoreDatabaseHelper.COLUMN_CUST_ID} = ?",
            arrayOf(customerId.toString())
        )
    }
}
