// 파일: MainActivity.kt
package com.example.mybookstore

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.mybookstore.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // 도서 목록 버튼 클릭 시 BookListActivity로 이동
        binding.btnBooks.setOnClickListener {
            startActivity(Intent(this, BookListActivity::class.java))
        }

        // 주문 목록 버튼 클릭 시 OrderListActivity로 이동
        binding.btnOrders.setOnClickListener {
            startActivity(Intent(this, OrderListActivity::class.java))
        }

        // 고객 목록 버튼 클릭 시 CustomerListActivity로 이동
        binding.btnCustomers.setOnClickListener {
            startActivity(Intent(this, CustomerListActivity::class.java))
        }
    }
}
