// 파일: CustomerListActivity.kt
package com.example.mybookstore

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.mybookstore.databinding.ActivityCustomerListBinding

class CustomerListActivity : AppCompatActivity() {
    private lateinit var binding: ActivityCustomerListBinding
    private lateinit var customerAdapter: CustomerAdapter
    private lateinit var customerDao: CustomerDao

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCustomerListBinding.inflate(layoutInflater)
        setContentView(binding.root)

        customerDao = CustomerDao(this)
        customerAdapter = CustomerAdapter(customerDao.getAllCustomers().toMutableList(), customerDao)

        binding.recyclerViewCustomers.apply {
            layoutManager = LinearLayoutManager(this@CustomerListActivity)
            adapter = customerAdapter
        }

        binding.btnAddCustomer.setOnClickListener {
            // 고객 추가 로직
        }
    }
}
