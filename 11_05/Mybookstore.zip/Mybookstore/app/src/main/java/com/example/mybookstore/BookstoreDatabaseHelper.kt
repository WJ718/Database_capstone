// 파일: BookStoreDatabaseHelper.kt
package com.example.mybookstore

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class BookStoreDatabaseHelper(context: Context) : SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

    override fun onCreate(db: SQLiteDatabase) {
        // Book 테이블 생성
        db.execSQL(
            "CREATE TABLE $TABLE_BOOKS (" +
                    "$COLUMN_BOOK_ID INTEGER PRIMARY KEY," +
                    "$COLUMN_BOOK_NAME TEXT," +
                    "$COLUMN_AUTHOR TEXT," +
                    "$COLUMN_PRICE INTEGER," +
                    "$COLUMN_CATEGORY TEXT," +
                    "$COLUMN_AMOUNT INTEGER," +
                    "$COLUMN_COUNTRY TEXT," +
                    "$COLUMN_PUBLISHER TEXT)"
        )

        // Customer 테이블 생성
        db.execSQL(
            "CREATE TABLE $TABLE_CUSTOMERS (" +
                    "$COLUMN_CUST_ID INTEGER PRIMARY KEY," +
                    "$COLUMN_NAME TEXT," +
                    "$COLUMN_BIRTH TEXT," +
                    "$COLUMN_GENDER TEXT," +
                    "$COLUMN_ADDRESS TEXT," +
                    "$COLUMN_PHONE_NUM TEXT)"
        )

        // Order 테이블 생성
        db.execSQL(
            "CREATE TABLE $TABLE_ORDERS (" +
                    "$COLUMN_ORDER_ID INTEGER PRIMARY KEY," +
                    "$COLUMN_BOOK_ID INTEGER," +
                    "$COLUMN_CUST_ID INTEGER," +
                    "$COLUMN_BOOK_NAME TEXT," +
                    "$COLUMN_AMOUNT INTEGER," +
                    "$COLUMN_SALE_PRICE INTEGER," +
                    "FOREIGN KEY($COLUMN_BOOK_ID) REFERENCES $TABLE_BOOKS($COLUMN_BOOK_ID)," +
                    "FOREIGN KEY($COLUMN_CUST_ID) REFERENCES $TABLE_CUSTOMERS($COLUMN_CUST_ID))"
        )
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS $TABLE_BOOKS")
        db.execSQL("DROP TABLE IF EXISTS $TABLE_CUSTOMERS")
        db.execSQL("DROP TABLE IF EXISTS $TABLE_ORDERS")
        onCreate(db)
    }

    companion object {
        private const val DATABASE_NAME = "bookstore.db"
        private const val DATABASE_VERSION = 1

        const val TABLE_BOOKS = "books"
        const val COLUMN_BOOK_ID = "bookid"
        const val COLUMN_BOOK_NAME = "bookname"
        const val COLUMN_AUTHOR = "author"
        const val COLUMN_PRICE = "price"
        const val COLUMN_CATEGORY = "category"
        const val COLUMN_AMOUNT = "amount"
        const val COLUMN_COUNTRY = "country"
        const val COLUMN_PUBLISHER = "publisher"

        const val TABLE_CUSTOMERS = "customers"
        const val COLUMN_CUST_ID = "custid"
        const val COLUMN_NAME = "name"
        const val COLUMN_BIRTH = "birth"
        const val COLUMN_GENDER = "gender"
        const val COLUMN_ADDRESS = "address"
        const val COLUMN_PHONE_NUM = "phonenum"

        const val TABLE_ORDERS = "orders"
        const val COLUMN_ORDER_ID = "orderid"
        const val COLUMN_SALE_PRICE = "saleprice"
    }
}
