package com.example.mybookstore.model


data class Order(
    val orderid: Int = 0,
    val bookname: String = "",
    val bookid: Int = 0,
    val custid: Int = 0,
    val amount: Int = 0,
    val saleprice: Int = 0,
)