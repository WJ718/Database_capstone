// 파일: BookListActivity.kt
package com.example.mybookstore

import android.app.AlertDialog
import android.os.Bundle
import android.view.LayoutInflater
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.mybookstore.databinding.ActivityBookListBinding
import com.example.mybookstore.databinding.DialogAddBookBinding
import com.example.mybookstore.model.Book

class BookListActivity : AppCompatActivity() {
    private lateinit var binding: ActivityBookListBinding
    private lateinit var bookAdapter: BookAdapter
    private lateinit var bookDao: BookDao

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityBookListBinding.inflate(layoutInflater)
        setContentView(binding.root)

        bookDao = BookDao(this)
        bookAdapter = BookAdapter(bookDao.getAllBooks().toMutableList(), bookDao)

        binding.recyclerView.apply {
            layoutManager = LinearLayoutManager(this@BookListActivity)
            adapter = bookAdapter
        }

        binding.btnAddBook.setOnClickListener {
            showAddBookDialog()
        }
    }

    private fun showAddBookDialog() {
        val dialogBinding = DialogAddBookBinding.inflate(LayoutInflater.from(this))
        val dialog = AlertDialog.Builder(this)
            .setTitle("Add Book")
            .setView(dialogBinding.root)
            .setPositiveButton("Add") { _, _ ->
                val bookId = dialogBinding.etBookId.text.toString().toIntOrNull()
                val bookName = dialogBinding.etBookName.text.toString()
                val author = dialogBinding.etAuthor.text.toString()
                val price = dialogBinding.etPrice.text.toString().toIntOrNull()
                val category = dialogBinding.etCategory.text.toString()
                val amount = dialogBinding.etAmount.text.toString().toIntOrNull()
                val country = dialogBinding.etCountry.text.toString()
                val publisher = dialogBinding.etPublisher.text.toString()

                if (bookId != null && price != null && amount != null) {
                    val newBook = Book(
                        bookid = bookId,
                        bookname = bookName,
                        author = author,
                        price = price,
                        category = category,
                        amount = amount,
                        country = country,
                        publisher = publisher
                    )
                    bookDao.addBook(newBook)
                    bookAdapter.updateBooks(bookDao.getAllBooks())
                    Toast.makeText(this, "Book added", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this, "Please fill all fields correctly", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Cancel", null)
            .create()

        dialog.show()
    }
}
