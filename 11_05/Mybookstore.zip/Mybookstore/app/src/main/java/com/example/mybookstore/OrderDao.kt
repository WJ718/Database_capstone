// 파일: OrderDao.kt
package com.example.mybookstore

import android.content.ContentValues
import android.content.Context
import com.example.mybookstore.model.Order

class OrderDao(context: Context) {
    private val dbHelper = BookStoreDatabaseHelper(context)

    fun addOrder(order: Order): Long {
        val db = dbHelper.writableDatabase
        val values = ContentValues().apply {
            put(BookStoreDatabaseHelper.COLUMN_ORDER_ID, order.orderid)
            put(BookStoreDatabaseHelper.COLUMN_BOOK_ID, order.bookid)
            put(BookStoreDatabaseHelper.COLUMN_CUST_ID, order.custid)
            put(BookStoreDatabaseHelper.COLUMN_BOOK_NAME, order.bookname)
            put(BookStoreDatabaseHelper.COLUMN_AMOUNT, order.amount)
            put(BookStoreDatabaseHelper.COLUMN_SALE_PRICE, order.saleprice)
        }
        return db.insert(BookStoreDatabaseHelper.TABLE_ORDERS, null, values)
    }

    fun getAllOrders(): List<Order> {
        val db = dbHelper.readableDatabase
        val cursor = db.query(
            BookStoreDatabaseHelper.TABLE_ORDERS,
            null, null, null, null, null, null
        )
        val orders = mutableListOf<Order>()
        with(cursor) {
            while (moveToNext()) {
                val order = Order(
                    orderid = getInt(getColumnIndexOrThrow(BookStoreDatabaseHelper.COLUMN_ORDER_ID)),
                    bookid = getInt(getColumnIndexOrThrow(BookStoreDatabaseHelper.COLUMN_BOOK_ID)),
                    custid = getInt(getColumnIndexOrThrow(BookStoreDatabaseHelper.COLUMN_CUST_ID)),
                    bookname = getString(getColumnIndexOrThrow(BookStoreDatabaseHelper.COLUMN_BOOK_NAME)),
                    amount = getInt(getColumnIndexOrThrow(BookStoreDatabaseHelper.COLUMN_AMOUNT)),
                    saleprice = getInt(getColumnIndexOrThrow(BookStoreDatabaseHelper.COLUMN_SALE_PRICE))
                )
                orders.add(order)
            }
        }
        cursor.close()
        return orders
    }

    fun deleteOrder(orderId: Int): Int {
        val db = dbHelper.writableDatabase
        return db.delete(
            BookStoreDatabaseHelper.TABLE_ORDERS,
            "${BookStoreDatabaseHelper.COLUMN_ORDER_ID} = ?",
            arrayOf(orderId.toString())
        )
    }
}
