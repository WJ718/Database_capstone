// 파일: CustomerAdapter.kt
package com.example.mybookstore

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.mybookstore.databinding.ItemCustomerBinding
import com.example.mybookstore.model.Customer

class CustomerAdapter(
    private var customers: MutableList<Customer>,
    private val customerDao: CustomerDao
) : RecyclerView.Adapter<CustomerAdapter.CustomerViewHolder>() {

    inner class CustomerViewHolder(private val binding: ItemCustomerBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(customer: Customer) {
            binding.tvName.text = customer.name
            binding.tvBirth.text = customer.birth
            binding.tvAddress.text = customer.address
            binding.tvPhoneNum.text = customer.phonenum

            binding.btnDeleteCustomer.setOnClickListener {
                customerDao.deleteCustomer(customer.custid)
                customers.removeAt(adapterPosition)
                notifyItemRemoved(adapterPosition)
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CustomerViewHolder {
        val binding = ItemCustomerBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return CustomerViewHolder(binding)
    }

    override fun onBindViewHolder(holder: CustomerViewHolder, position: Int) {
        holder.bind(customers[position])
    }

    override fun getItemCount(): Int = customers.size

    fun updateCustomers(newCustomers: List<Customer>) {
        customers.clear()
        customers.addAll(newCustomers)
        notifyDataSetChanged()
    }
}
