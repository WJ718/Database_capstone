// 파일: OrderAdapter.kt
package com.example.mybookstore

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.mybookstore.databinding.ItemOrderBinding
import com.example.mybookstore.model.Order

class OrderAdapter(
    private var orders: MutableList<Order>,
    private val orderDao: OrderDao
) : RecyclerView.Adapter<OrderAdapter.OrderViewHolder>() {

    inner class OrderViewHolder(private val binding: ItemOrderBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(order: Order) {
            binding.tvOrderId.text = order.orderid.toString()
            binding.tvBookName.text = order.bookname
            binding.tvAmount.text = order.amount.toString()
            binding.tvSalePrice.text = order.saleprice.toString()

            binding.btnDeleteOrder.setOnClickListener {
                orderDao.deleteOrder(order.orderid)
                orders.removeAt(adapterPosition)
                notifyItemRemoved(adapterPosition)
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): OrderViewHolder {
        val binding = ItemOrderBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return OrderViewHolder(binding)
    }

    override fun onBindViewHolder(holder: OrderViewHolder, position: Int) {
        holder.bind(orders[position])
    }

    override fun getItemCount(): Int = orders.size

    fun updateOrders(newOrders: List<Order>) {
        orders.clear()
        orders.addAll(newOrders)
        notifyDataSetChanged()
    }
}
