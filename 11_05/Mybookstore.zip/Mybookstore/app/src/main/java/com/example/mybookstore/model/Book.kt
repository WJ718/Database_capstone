package com.example.mybookstore.model

data class Book(
    val bookid: Int = 0,
    val bookname: String = "",
    val author: String = "",
    val price: Int = 0,
    val category: String = "",
    val amount : Int = 0,
    val country: String = "",
    val publisher: String = "",
)