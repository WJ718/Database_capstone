package com.example.mybookstore.model

data class Customer(
    val custid: Int = 0,
    val name: String ="",
    val gender: String = "",
    val birth: String = "",
    val address: String = "",
    val phonenum: String = "",
)