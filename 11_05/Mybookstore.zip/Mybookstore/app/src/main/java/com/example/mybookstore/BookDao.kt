// 파일: BookDao.kt
package com.example.mybookstore

import android.content.ContentValues
import android.content.Context
import com.example.mybookstore.model.Book

class BookDao(context: Context) {
    private val dbHelper = BookStoreDatabaseHelper(context)

    fun addBook(book: Book): Long {
        val db = dbHelper.writableDatabase
        val values = ContentValues().apply {
            put(BookStoreDatabaseHelper.COLUMN_BOOK_ID, book.bookid)
            put(BookStoreDatabaseHelper.COLUMN_BOOK_NAME, book.bookname)
            put(BookStoreDatabaseHelper.COLUMN_AUTHOR, book.author)
            put(BookStoreDatabaseHelper.COLUMN_PRICE, book.price)
            put(BookStoreDatabaseHelper.COLUMN_CATEGORY, book.category)
            put(BookStoreDatabaseHelper.COLUMN_AMOUNT, book.amount)
            put(BookStoreDatabaseHelper.COLUMN_COUNTRY, book.country)
            put(BookStoreDatabaseHelper.COLUMN_PUBLISHER, book.publisher)
        }
        return db.insert(BookStoreDatabaseHelper.TABLE_BOOKS, null, values)
    }

    fun getAllBooks(): List<Book> {
        val db = dbHelper.readableDatabase
        val cursor = db.query(
            BookStoreDatabaseHelper.TABLE_BOOKS,
            null, null, null, null, null, null
        )
        val books = mutableListOf<Book>()
        with(cursor) {
            while (moveToNext()) {
                val book = Book(
                    bookid = getInt(getColumnIndexOrThrow(BookStoreDatabaseHelper.COLUMN_BOOK_ID)),
                    bookname = getString(getColumnIndexOrThrow(BookStoreDatabaseHelper.COLUMN_BOOK_NAME)),
                    author = getString(getColumnIndexOrThrow(BookStoreDatabaseHelper.COLUMN_AUTHOR)),
                    price = getInt(getColumnIndexOrThrow(BookStoreDatabaseHelper.COLUMN_PRICE)),
                    category = getString(getColumnIndexOrThrow(BookStoreDatabaseHelper.COLUMN_CATEGORY)),
                    amount = getInt(getColumnIndexOrThrow(BookStoreDatabaseHelper.COLUMN_AMOUNT)),
                    country = getString(getColumnIndexOrThrow(BookStoreDatabaseHelper.COLUMN_COUNTRY)),
                    publisher = getString(getColumnIndexOrThrow(BookStoreDatabaseHelper.COLUMN_PUBLISHER))
                )
                books.add(book)
            }
        }
        cursor.close()
        return books
    }

    fun deleteBook(bookId: Int): Int {
        val db = dbHelper.writableDatabase
        return db.delete(
            BookStoreDatabaseHelper.TABLE_BOOKS,
            "${BookStoreDatabaseHelper.COLUMN_BOOK_ID} = ?",
            arrayOf(bookId.toString())
        )
    }
}
