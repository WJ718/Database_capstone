// 파일: BookAdapter.kt
package com.example.mybookstore

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.mybookstore.databinding.ItemBookBinding
import com.example.mybookstore.model.Book

class BookAdapter(
    private var books: MutableList<Book>,
    private val bookDao: BookDao
) : RecyclerView.Adapter<BookAdapter.BookViewHolder>() {

    inner class BookViewHolder(private val binding: ItemBookBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(book: Book) {
            binding.tvBookName.text = "${book.bookname} (책 제목)"
            binding.tvAuthor.text = "${book.author} (저자)"
            binding.tvPrice.text = "${book.price}원 (가격)"
            binding.tvBookId.text = "${book.bookid} (도서 ID)"
            binding.tvCategory.text = "${book.category} (카테고리)"
            binding.tvAmount.text = "${book.amount} (수량)"
            binding.tvCountry.text = "${book.country} (국가)"
            binding.tvPublisher.text = "${book.publisher} (출판사)"

            binding.btnDelete.setOnClickListener {
                bookDao.deleteBook(book.bookid)
                books.removeAt(adapterPosition)
                notifyItemRemoved(adapterPosition)
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): BookViewHolder {
        val binding = ItemBookBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return BookViewHolder(binding)
    }

    override fun onBindViewHolder(holder: BookViewHolder, position: Int) {
        holder.bind(books[position])
    }

    override fun getItemCount(): Int = books.size

    fun updateBooks(newBooks: List<Book>) {
        books.clear()
        books.addAll(newBooks)
        notifyDataSetChanged()
    }
}
